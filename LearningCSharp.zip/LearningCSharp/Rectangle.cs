﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningCSharp
{
    class Rectangle
    {
        private double _length = 0;
        private double _width = 0;
        public string Length
        {
            get { return _length.ToString(); }
            set
            {
                int n = 0;
                string buffer = value;
                int.TryParse(buffer, out n);
                _length = n;
            }
        }
        public string Width
        {
            get { return _width.ToString(); }
            set
            {
                int n = 0;
                string buffer = value;
                int.TryParse(buffer, out n);
                _width = n;
            }
        }

        public double Area
        {
            get { return _length * _width; }
        }
        public double perimeter
        {
            get { return (_length * 2) + (_width * 2); }
        }
        public void PrintArea()
        {
            Console.WriteLine($"Area is: {_length * _width}");
        }
        public void PrintPerimeter()
        {
            Console.WriteLine($"Perimeter is: {(_width * 2) + (_length * 2)}");
        }
        public bool GetLengthAndWidth()
        {
            Console.Write("Enter Length: ");
            this.Length = Console.ReadLine();
            Console.Write("Enter Width: ");
            this.Width = Console.ReadLine();
            return true;
        }
    }
}
